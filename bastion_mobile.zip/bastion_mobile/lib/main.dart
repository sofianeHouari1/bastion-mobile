import 'package:flutter/material.dart';
import 'config.dart';
import 'settings_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final config = await AppConfig.load();
  config.applyCertPolicy();
  runApp(BastionApp(config: config));
}

class BastionApp extends StatelessWidget {
  const BastionApp({super.key, required this.config});
  final AppConfig config;

  @override
  Widget build(BuildContext context) {
    // Couleurs de la charte Bastion (theme sombre par defaut)
    const brand = Color(0xFF6FA3CF);
    return MaterialApp(
      title: 'Bastion',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1F4E79)), useMaterial3: true),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.dark, surface: const Color(0xFF161E25)),
        scaffoldBackgroundColor: const Color(0xFF0E1419),
        useMaterial3: true,
      ),
      home: HomePage(config: config),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.config});
  final AppConfig config;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BASTION'),
        actions: [
          IconButton(
            tooltip: 'Serveur',
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SettingsPage(config: config))),
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.shield_outlined, size: 64),
            const SizedBox(height: 16),
            const Text('Communications souveraines', style: TextStyle(fontSize: 20)),
            const SizedBox(height: 8),
            Text('Serveur : ${config.bastionUrl}', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            const Text('Connexion Keycloak, messages et appels : prochaines etapes.', textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }
}

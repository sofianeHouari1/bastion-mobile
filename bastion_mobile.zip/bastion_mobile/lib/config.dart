import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';

/// Configuration du serveur, modifiable dans l'ecran "Serveur" (aucune adresse n'est ecrite en dur ailleurs).
class AppConfig {
  String bastionUrl;      // serveur Bastion (API, messages, fichiers)
  String keycloakUrl;     // Keycloak (connexion)
  String realm;
  String clientId;
  String sipWss;          // WebSocket securise d'Asterisk
  String sipDomain;       // domaine SIP
  String turnUrl;         // optionnel, ex. turn:192.168.1.88:3478
  bool acceptTestCert;    // accepter le certificat de test (developpement uniquement)

  AppConfig({
    this.bastionUrl = 'https://192.168.1.88:8443',
    this.keycloakUrl = 'https://192.168.1.88:8080',
    this.realm = 'webrtc',
    this.clientId = 'webrtc-ihm',
    this.sipWss = 'wss://192.168.1.88:8089/ws',
    this.sipDomain = '192.168.1.88',
    this.turnUrl = '',
    this.acceptTestCert = true,
  });

  static const _k = 'bastion_config_v1';

  static Future<AppConfig> load() async {
    final p = await SharedPreferences.getInstance();
    final d = AppConfig();
    String g(String k, String def) => p.getString('$_k.$k') ?? def;
    return AppConfig(
      bastionUrl: g('bastionUrl', d.bastionUrl),
      keycloakUrl: g('keycloakUrl', d.keycloakUrl),
      realm: g('realm', d.realm),
      clientId: g('clientId', d.clientId),
      sipWss: g('sipWss', d.sipWss),
      sipDomain: g('sipDomain', d.sipDomain),
      turnUrl: g('turnUrl', d.turnUrl),
      acceptTestCert: p.getBool('$_k.acceptTestCert') ?? d.acceptTestCert,
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('$_k.bastionUrl', bastionUrl.trim());
    await p.setString('$_k.keycloakUrl', keycloakUrl.trim());
    await p.setString('$_k.realm', realm.trim());
    await p.setString('$_k.clientId', clientId.trim());
    await p.setString('$_k.sipWss', sipWss.trim());
    await p.setString('$_k.sipDomain', sipDomain.trim());
    await p.setString('$_k.turnUrl', turnUrl.trim());
    await p.setBool('$_k.acceptTestCert', acceptTestCert);
    applyCertPolicy();
  }

  /// Hotes configures : seuls ceux-la peuvent etre acceptes avec un certificat de test.
  Set<String> get hosts {
    final out = <String>{};
    for (final u in [bastionUrl, keycloakUrl, sipWss]) {
      final h = Uri.tryParse(u.trim())?.host ?? '';
      if (h.isNotEmpty) out.add(h);
    }
    return out;
  }

  /// Si l'option est activee, accepte le certificat auto-signe, uniquement pour les hotes ci-dessus.
  void applyCertPolicy() {
    final allowed = hosts;
    final enabled = acceptTestCert;
    HttpOverrides.global = _TestCertOverrides(enabled, allowed);
  }
}

class _TestCertOverrides extends HttpOverrides {
  _TestCertOverrides(this.enabled, this.allowed);
  final bool enabled;
  final Set<String> allowed;

  @override
  HttpClient createHttpClient(SecurityContext? context) {
    final c = super.createHttpClient(context);
    c.badCertificateCallback = (cert, host, port) => enabled && allowed.contains(host);
    return c;
  }
}

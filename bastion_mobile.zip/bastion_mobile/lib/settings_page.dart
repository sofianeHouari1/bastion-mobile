import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.config});
  final AppConfig config;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final Map<String, TextEditingController> c;
  late bool acceptCert;
  String result = '';
  bool busy = false;

  @override
  void initState() {
    super.initState();
    final k = widget.config;
    c = {
      'bastion': TextEditingController(text: k.bastionUrl),
      'keycloak': TextEditingController(text: k.keycloakUrl),
      'realm': TextEditingController(text: k.realm),
      'client': TextEditingController(text: k.clientId),
      'wss': TextEditingController(text: k.sipWss),
      'domain': TextEditingController(text: k.sipDomain),
      'turn': TextEditingController(text: k.turnUrl),
    };
    acceptCert = k.acceptTestCert;
  }

  void _apply() {
    final k = widget.config;
    k.bastionUrl = c['bastion']!.text;
    k.keycloakUrl = c['keycloak']!.text;
    k.realm = c['realm']!.text;
    k.clientId = c['client']!.text;
    k.sipWss = c['wss']!.text;
    k.sipDomain = c['domain']!.text;
    k.turnUrl = c['turn']!.text;
    k.acceptTestCert = acceptCert;
  }

  Future<void> _save() async {
    _apply();
    await widget.config.save();
    if (mounted) Navigator.of(context).pop(true);
  }

  Future<void> _test() async {
    _apply();
    widget.config.applyCertPolicy();
    setState(() { busy = true; result = 'Test en cours...'; });
    final k = widget.config;
    final lines = <String>[];
    Future<void> probe(String label, String url) async {
      try {
        final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 6));
        lines.add('OK  $label (${r.statusCode})');
      } catch (e) {
        lines.add('ECHEC  $label : ${e.toString().split('\n').first}');
      }
    }
    await probe('Bastion', k.bastionUrl);
    await probe('Keycloak', '${k.keycloakUrl}/realms/${k.realm}/.well-known/openid-configuration');
    if (mounted) setState(() { busy = false; result = lines.join('\n'); });
  }

  Widget _field(String key, String label, {String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c[key],
          keyboardType: TextInputType.url,
          autocorrect: false,
          decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Serveur')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _field('bastion', 'Adresse de Bastion', hint: 'https://192.168.1.88:8443'),
          _field('keycloak', 'Adresse de Keycloak', hint: 'https://192.168.1.88:8080'),
          Row(children: [
            Expanded(child: _field('realm', 'Realm')),
            const SizedBox(width: 12),
            Expanded(child: _field('client', 'Client ID')),
          ]),
          _field('wss', 'Asterisk (WebSocket securise)', hint: 'wss://192.168.1.88:8089/ws'),
          _field('domain', 'Domaine SIP', hint: '192.168.1.88'),
          _field('turn', 'Serveur TURN (optionnel)', hint: 'turn:192.168.1.88:3478'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Accepter le certificat de test'),
            subtitle: const Text('Developpement uniquement, limite aux adresses ci-dessus. A desactiver en production.'),
            value: acceptCert,
            onChanged: (v) => setState(() => acceptCert = v),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: busy ? null : _test, child: const Text('Tester la connexion'))),
            const SizedBox(width: 12),
            Expanded(child: FilledButton(onPressed: busy ? null : _save, child: const Text('Enregistrer'))),
          ]),
          if (result.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 16), child: SelectableText(result)),
        ],
      ),
    );
  }
}

# Bastion mobile (squelette)

Contenu : ecran **Serveur** configurable (adresses Bastion et Keycloak, realm, client ID, WebSocket Asterisk,
domaine SIP, TURN, acceptation du certificat de test) + test de connexion.

## Premier lancement
1. Installer Flutter, puis dans ce dossier : `flutter create . --platforms=android` (ajoute les dossiers Android sans toucher a lib/).
2. `flutter pub get`
3. Brancher le telephone Android (mode developpeur) puis `flutter run`.
4. Le telephone doit etre sur le meme Wi-Fi que le PC. Dans l'ecran Serveur, mettre l'IP du PC.
5. Pare-feu Windows : autoriser les ports 8443 (Bastion), 8080 (Keycloak), 8089 (Asterisk WSS).
